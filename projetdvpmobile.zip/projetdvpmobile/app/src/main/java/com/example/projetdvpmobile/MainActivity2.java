package com.example.projetdvpmobile;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class MainActivity2 extends AppCompatActivity {
    ImageView img;
    EditText Email;
    EditText mp;
    Button btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        img=findViewById(R.id.img);
        Email=findViewById(R.id.Email);
        mp=findViewById(R.id.mp);
        btn1=findViewById(R.id.Envoyer);
        String email=getIntent().getStringExtra("Email");
        Email.setText(email);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=Email.getText().toString();
                Intent I= new(MainActivity2.this,MainActivity3.class);
                I.putExtra("Email" , s);
                startActivity(I);

            }
        });




    }
}