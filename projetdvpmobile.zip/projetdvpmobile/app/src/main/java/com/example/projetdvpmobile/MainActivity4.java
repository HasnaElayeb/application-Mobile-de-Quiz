package com.example.projetdvpmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity4 extends AppCompatActivity {
    TextView taille;
    EditText Taille;
    TextView Poids;
    EditText poids;
    TextView age;
    EditText Age;
    String sexe;
    RadioButton homme;
    RadioButton femme;
    RadioButton sédentaire;
    RadioButton PA;
    RadioButton A;
    RadioButton TA;
    Button btn3;
    String activity;
    TextView resulta;
    EditText RES;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        taille=findViewById(R.id.taille);
        Taille=findViewById(R.id.Taille);
        Poids=findViewById(R.id.Poids);
        poids=findViewById(R.id.poids);
        age=findViewById(R.id.age);
        Age=findViewById(R.id.Age);
        RES=findViewById(R.id.rz);
        resulta=findViewById(R.id.RZ);
        homme=findViewById(R.id.homme);
        femme=findViewById(R.id.femme);
        sédentaire=findViewById(R.id.sédentaire);
        PA=findViewById(R.id.peuActif);
        A=findViewById(R.id.Actif);
        TA=findViewById(R.id.trésActif);
        btn3=findViewById(R.id.valider);
        btn3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
             if(homme.isChecked()){
                 sexe= "homme"}
             if(femme.isChecked()){
                sexe= "femme"}
                Toast.makeText(MainActivity4.this, "genre est"+sexe, Toast.LENGTH_SHORT).show();
             if(sédentaire.isChecked()){
                 activity="sédentaire"}
             if(PA.isChecked()){
                 activity="PA"}
             if(A.isChecked()){
                 activity="A"}
             if(TA.isChecked()){
                 activity="TA"}

             double t =Double.parseDouble(taille.getText().toString());
             double p =Double.parseDouble(Poids.getText().toString());
             double x =p/(t*t);
             String RZ="";
                    if(x>=40){RZ="obesité morbide ou massive";
                        else if(x<40&&x>=35){ RZ="obesité sévere";}
                        else if(x<35&&x>=30){ RZ="obesité nodérée";}
                        else if(x<30&&x>=25){ RZ="surpoids";}
                        else if(x<25&&x>=18.5){ RZ="corpulence  normale";}
                        else if(x<18.5&&x>=16.5){ RZ="massive";}
                        else RZ="Famine";
                        resulta.setText(RZ);





    }
}