package com.example.projetdvpmobile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {
    TextView tille;
    TextView Nom;
    EditText nom;
    TextView Prénom;
    EditText prénom;
    TextView email;
    EditText Email;
    TextView phone;
    EditText Phone;
    Button btn2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        tille=findViewById(R.id.title);
        Nom=findViewById(R.id.Nom);
        nom=findViewById(R.id.nom);
        Prénom=findViewById(R.id.Prenom);
        prénom=findViewById(R.id.prenom);
        email=findViewById(R.id.email);
        Email=findViewById(R.id.Email);
        phone=findViewById(R.id.phone);
        Phone=findViewById(R.id.Phone);
        btn2=findViewById(R.id.valider);
        String nom=getIntent().getStringExtra("Nom");
        String prenom=getIntent().getStringExtra("Prénom");
        String Email=getIntent().getStringExtra("Email");
        btn2.setText(email);
        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent I= new(MainActivity3.this,MainActivity4.class);
        startActivity(I);
            }
        });


    }
}