package com.example.projetdvpmobile;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.text.BreakIterator;

public class MainActivity extends AppCompatActivity {
    EditText Nom;
    EditText Prénom;
    EditText Email;
    String sexe;
    RadioButton homme;
    RadioButton femme;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Nom=findViewById(R.id.Nom);
        Prénom=findViewById(R.id.Prénom);
        Email=findViewById(R.id.Email);
        homme=findViewById(R.id.homme);
        if(homme.isChecked()){
            sexe= "homme"}
        femme=findViewById(R.id.femme);
        if(femme.isChecked()){
            sexe= "femme"}
        btn=findViewById(R.id.Envoyer);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String s=Email.getText().toString();
                String s1=Nom.getText().toString();
                String s2=Prénom.getText().toString();
                Intent I= new(MainActivity.this,MainActivity2.class);
                I.putExtra("Email" , s);
                startActivity(I);
                Intent I= new(MainActivity.this,MainActivity3.class);
                I.putExtra("Nom" , s1);
                I.putExtra("Prénom" , s2);
                startActivity(I);
                if(homme.isChecked()){
                    sexe= "homme"}
                if(femme.isChecked()){
                    sexe= "femme"}
                Toast.makeText(MainActivity.this, "genre est"+sexe, Toast.LENGTH_SHORT).show();

                }





            }
        });




    }
}