import 'package:flutter/material.dart';

class ResultScreen extends StatelessWidget {
  final int? score;
  final int? totalQuestions;

  ResultScreen({Key? key, this.score, this.totalQuestions}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('')),
      backgroundColor:
          Color(0xffedbdf6), // Défin, // Couleur de fond de l'écran
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Résultat du Quiz',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.purple, // Couleur du texte en blanc
              ),
            ),
            SizedBox(height: 20),
            Text(
              'Votre score est de $score/$totalQuestions.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 18,
                color: Colors.purple, // Couleur du texte en blanc
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context); // Retour à l'écran précédent
              },
              style: ElevatedButton.styleFrom(
                primary:
                    Color(0xff934be5), // Couleur de fond du bouton en blanc
                onPrimary: Colors.white, // Couleur du texte du bouton
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 20),
              ),
              child: Text(
                'Rejouer',
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
