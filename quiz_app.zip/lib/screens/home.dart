import 'package:flutter/material.dart';
import 'package:quiz_app/screens/quiz_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(''),
      ),
      backgroundColor: Color(
          0xffedbdf6), // Définir la couleur d'arrière-plan à violet (purple)
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      QuizScreen()), // Ajout de la parenthèse fermante ici
            );
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(
                horizontal: 1.0, vertical: 9.0), // Ajustez le padding au besoin
            child: Row(
              mainAxisSize: MainAxisSize
                  .min, // Assurez-vous que la ligne prend le moins d'espace possible
              children: [
                Text(
                  'Start Quiz',
                  style: TextStyle(
                      fontSize: 16), // Définissez la taille de la police à 16
                ),
                Icon(
                  Icons.arrow_forward_ios, // Icône à côté du texte
                ),
              ],
            ),
          ),
          style: ElevatedButton.styleFrom(
            primary: Color(0xff934be5), // Couleur de fond
            onPrimary: Colors.white, // Couleur du texte
          ),
        ),
      ),
    );
  }
}
