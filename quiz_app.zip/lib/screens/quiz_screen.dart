import 'package:flutter/material.dart';
import 'package:quiz_app/models/question.dart';
import 'package:quiz_app/services/quiz_service.dart';
import 'package:quiz_app/screens/resultat_screen.dart';
import 'dart:async'; // Add this import for using Timer

class QuizScreen extends StatefulWidget {
  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  late Future<List<Question>>? questions;
  int currentIndex = 0;
  int score = 0;
  bool answered = false;
  int selectedIndex = -1; // Variable to store the selected index
  late Timer _timer; // Timer variable
  int _timerSeconds = 10; // Initial timer duration

  @override
  void initState() {
    super.initState();
    questions = QuizService().getQuestions();
    startTimer(); // Start the timer when the screen initializes
  }

  void startTimer() {
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      setState(() {
        if (_timerSeconds > 0) {
          _timerSeconds--;
        } else {
          // Time's up, move to the next question
          nextQuestion();
        }
      });
    });
  }

  void resetTimer() {
    _timer.cancel();
    _timerSeconds = 15;
    startTimer();
  }

  @override
  void dispose() {
    _timer.cancel(); // Cancel the timer when the widget is disposed
    super.dispose();
  }

  void checkAnswer(int index) {
    if (questions != null && !answered) {
      questions!.then((value) {
        bool isCorrect = (index == value[currentIndex].correctIndex);
        setState(() {
          answered = true;
          selectedIndex = index; // Set the selected index
          if (isCorrect) {
            score++;
          }
        });

        resetTimer(); // Reset the timer when the user answers the question
        Future.delayed(Duration(seconds: 2), () {
          nextQuestion();
        });
      }).catchError((error) {
        print(error);
      });
    }
  }

  void nextQuestion() {
    if (questions != null) {
      questions!.then((value) {
        if (currentIndex < value.length - 1) {
          setState(() {
            currentIndex++;
            answered = false;
            selectedIndex = -1; // Reset the selected index
            resetTimer(); // Reset the timer for the next question
          });
        } else {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) =>
                  ResultScreen(score: score, totalQuestions: value.length),
            ),
          );
        }
      }).catchError((error) {
        print(error);
      });
    }
  }

  void previousQuestion() {
    if (currentIndex > 0) {
      setState(() {
        currentIndex--;
        answered = false;
        selectedIndex = -1; // Reset the selected index
        resetTimer(); // Reset the timer for the previous question
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('')),
      body: Padding(
        padding: EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            FutureBuilder<List<Question>>(
              future: questions,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                } else if (snapshot.hasError) {
                  return Center(child: Text('Error: ${snapshot.error}'));
                } else if (snapshot.hasData) {
                  List<Question> data = snapshot.data!;
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SizedBox(height: 20.0),
                      Text(
                          ': $_timerSeconds seconds'), // Display the remaining time
                      SizedBox(height: 20.0),
                      Container(
                        padding: EdgeInsets.all(10.0),
                        decoration: BoxDecoration(
                          color: Colors.pink[100],
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: Text(
                          data[currentIndex].question,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20.0,
                            color: Colors.purple,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      SizedBox(height: 20.0),
                      ...data[currentIndex]
                          .options
                          .asMap()
                          .entries
                          .map((entry) {
                        int index = entry.key;
                        String option = entry.value;
                        bool isCorrect =
                            (index == data[currentIndex].correctIndex);
                        return Padding(
                          padding: EdgeInsets.symmetric(vertical: 10.0),
                          child: ElevatedButton(
                            onPressed: () {
                              checkAnswer(index);
                            },
                            style: ElevatedButton.styleFrom(
                              primary: selectedIndex == index
                                  ? (isCorrect ? Colors.green : Colors.red)
                                  : Colors.pink[100],
                              onPrimary: Colors.purple,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              padding: EdgeInsets.symmetric(vertical: 15.0),
                            ),
                            child: Text(option),
                          ),
                        );
                      }).toList(),
                      SizedBox(height: 20.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          if (currentIndex > 0)
                            Expanded(
                              child: ElevatedButton(
                                onPressed: previousQuestion,
                                style: ElevatedButton.styleFrom(
                                  primary: Color(0xff934be5),
                                  onPrimary: Colors.white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  padding: EdgeInsets.symmetric(vertical: 15.0),
                                ),
                                child: Icon(Icons.arrow_back),
                              ),
                            ),
                          Spacer(),
                          Text(
                            '${currentIndex + 1}/${data.length}',
                            style: TextStyle(
                                fontSize: 20.0, color: Color(0xff934be5)),
                          ),
                          Spacer(),
                          if (currentIndex < data.length - 1)
                            Expanded(
                              child: ElevatedButton(
                                onPressed: nextQuestion,
                                style: ElevatedButton.styleFrom(
                                  primary: Color(0xff934be5),
                                  onPrimary: Colors.white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                  padding: EdgeInsets.symmetric(vertical: 15.0),
                                ),
                                child: Icon(Icons.arrow_forward),
                              ),
                            ),
                        ],
                      ),
                    ],
                  );
                } else {
                  return Center(child: Text('No data'));
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
